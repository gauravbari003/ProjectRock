package com.one;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class MainApp {
    public static void main(String[] args) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("myPU");
        EntityManager em = emf.createEntityManager();

        // Create a Person and Address
        Person person = new Person();
        person.setName("John Doe");

        Address address = new Address();
        address.setStreet("123 Main St");
        address.setCity("New York");
        address.setZipCode("10001");

        person.setAddress(address);

        // Persist the Person and Address
        em.getTransaction().begin();
        em.persist(person);
        em.getTransaction().commit();

        // Retrieve the Person and their Address
        Person retrievedPerson = em.find(Person.class, person.getId());
        System.out.println("Person: " + retrievedPerson.getName());
        System.out.println("Address: " + retrievedPerson.getAddress().getStreet());

        em.close();
        emf.close();
    }
}
